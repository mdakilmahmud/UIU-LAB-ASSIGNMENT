#Calculate the sum of numbers from 1 to 10 using a for loop.
# Sample Output: 55

# Solution:
sum=0
for i in range(1,11):
      sum+=i
print(sum)