# list=[1,2,3,4,5] Write a program to print cube of the elements in the given list.
# Sample Input:
# Sample Output:18
27
64
125

# Solution:
lst=[1,2,3,4,5]
for i in lst:
      print(i**3)